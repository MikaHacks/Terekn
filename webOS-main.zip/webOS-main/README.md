# TerbiumOS web
This web os is packed full of feature ***AND MUCH MORE TO COME***
![image](https://user-images.githubusercontent.com/49733954/191388633-1b1f27b0-3ceb-4043-a741-6c3d72440da8.png)
![image](https://user-images.githubusercontent.com/49733954/191388585-055bff3e-3b09-4d46-9c92-e457a51da8d7.png)
![image](https://user-images.githubusercontent.com/49733954/191388608-6cb6f5e0-a6b5-47c8-a50f-a6b3791a1778.png)
