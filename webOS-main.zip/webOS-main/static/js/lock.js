const cancelLock = document.querySelector(".cancel");

cancelLock.addEventListener("click", () => {
    window.open("./index.html", "_self");
})